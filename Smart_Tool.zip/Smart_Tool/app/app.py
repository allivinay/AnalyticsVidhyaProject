import gradio as gr
from app.search import search_courses
from app.llm import refine_query

def find_relevant_courses(query):
    refined_query = refine_query(query)
    top_courses = search_courses(refined_query)
    return top_courses

# Create the Gradio interface
gr.Interface(fn=find_relevant_courses, inputs="text", outputs="text").launch()
